def main(event, context):
    print("hi")

if __name__ == '__main__':
    main(None, None)

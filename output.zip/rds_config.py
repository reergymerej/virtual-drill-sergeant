import os

#config file containing credentials for RDS instance
db_username = "postgres"
db_name = "playground"
db_password = os.environ['DB_PASSWORD']
